/*:
# Implicitly unwrapped optionals
Like regular optionals, implicitly unwrapped optionals might contain a value or they might be `nil`. However, unlike regular optionals you don’t need to unwrap them in order to use them: you can use them as if they weren’t optional at all.

Implicitly unwrapped optionals are created by adding an exclamation mark after your type name, like this:
*/
//#-editable-code Enter your code here
let age: Int! = nil
//#-end-editable-code
/*:
Because they behave as if they were already unwrapped, you don’t need `if let` or `guard let` to use implicitly unwrapped optionals. However, if you try to use them and they have no value – if they are `nil` – your code crashes.

Implicitly unwrapped optionals exist because sometimes a variable will start life as nil, but will always have a value before you need to use it. Because you know they will have a value by the time you need them, it’s helpful not having to write `if let` all the time.

That being said, if you’re able to use regular optionals instead it’s generally a good idea.*/
